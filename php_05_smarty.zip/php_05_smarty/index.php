<?php
require_once dirname(__FILE__).'/config.php';

include _ROOT_PATH.'/app/calc.php';