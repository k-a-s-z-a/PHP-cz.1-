<?php
define('_SERVER_NAME', 'localhost');
define('_SERVER_URL', 'http://' . _SERVER_NAME);
define('_APP_ROOT', '/projekty_php/php_05_smarty/');
define('_APP_URL', _SERVER_URL . _APP_ROOT);
define('_ROOT_PATH', dirname(__FILE__)); // <-- Poprawiona ścieżka

// Opcjonalnie, sprawdzenie czy działa
// echo "ROOT_PATH: " . _ROOT_PATH;
?>
